package Cola;

import Lista.Nodo;

public class Cola {
    private Nodo frente;
    private Nodo fondo;

    public Cola() {
        frente = null;
        fondo = null;
    }

    public void enqueue(int valor) {
        Nodo nuevo = new Nodo(valor);
        if (estaVacia()) {
            frente = nuevo;
            fondo = nuevo;
        } else {
            fondo.siguiente = nuevo;
            fondo = nuevo;
        }
    }
    
    public Nodo getFrente() {
        return frente;
    }

    public int dequeue() {
        if (estaVacia()) {
            throw new RuntimeException("La cola está vacía");
        }
        int valor = frente.valor;
        frente = frente.siguiente;
        if (frente == null) {
            fondo = null;
        }
        return valor;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public void mostrar() {
        Nodo actual = frente;
        System.out.print("Cola: ");
        while (actual != null) {
            System.out.print(actual.valor + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }
}


