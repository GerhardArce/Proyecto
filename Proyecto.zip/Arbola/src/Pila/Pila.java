package Pila;

import Lista.Nodo;

public class Pila {
    private Nodo cima;

    public Pila() {
        cima = null;
    }

    public void push(int valor) {
        Nodo nuevo = new Nodo(valor);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    public int pop() {
        if (estaVacia()) {
            throw new RuntimeException("La pila está vacía");
        }
        int valor = cima.valor;
        cima = cima.siguiente;
        return valor;
    }

    public boolean estaVacia() {
        return cima == null;
    }
    
    public Nodo getTope() {
        return cima;
    }
    
    public Nodo getCima() {
        return cima;
    }

    public void mostrar() {
        Nodo actual = cima;
        System.out.print("Pila: ");
        while (actual != null) {
            System.out.print(actual.valor + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }
}




