package arbolbinario;

public class NodoArbol {
    public int valor, altura;
    public NodoArbol hijoIzquierdo;
    public NodoArbol hijoDerecho;

    public NodoArbol(int valor) {
        this.valor = valor;
        this.altura = 0;
        this.hijoIzquierdo = null;
        this.hijoDerecho = null;
    }
}
