package arbolbinario;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities; // Esta línea ya está
import Ventana.Ventana; 

public class Arbol {
    private NodoArbol raiz;

    public Arbol() {
        raiz = null;
    }

    public NodoArbol buscar(int valor, NodoArbol nodo) {
        if (nodo == null) {
            return null;
        } else if (nodo.valor == valor) {
            return nodo;
        } else if (valor < nodo.valor) {
            return buscar(valor, nodo.hijoIzquierdo);
        } else {
            return buscar(valor, nodo.hijoDerecho);
        }
    }

    public int obtenerAltura(NodoArbol nodo) {
        return (nodo == null) ? -1 : nodo.altura;
    }

    public NodoArbol rotacionIzquierda(NodoArbol c) {
        NodoArbol auxiliar = c.hijoIzquierdo;
        c.hijoIzquierdo = auxiliar.hijoDerecho;
        auxiliar.hijoDerecho = c;
        c.altura = Math.max(obtenerAltura(c.hijoIzquierdo), obtenerAltura(c.hijoDerecho)) + 1;
        auxiliar.altura = Math.max(obtenerAltura(auxiliar.hijoIzquierdo), obtenerAltura(auxiliar.hijoDerecho)) + 1;
        return auxiliar;
    }

    public NodoArbol rotacionDerecha(NodoArbol c) {
        NodoArbol auxiliar = c.hijoDerecho;
        c.hijoDerecho = auxiliar.hijoIzquierdo;
        auxiliar.hijoIzquierdo = c;
        c.altura = Math.max(obtenerAltura(c.hijoIzquierdo), obtenerAltura(c.hijoDerecho)) + 1;
        auxiliar.altura = Math.max(obtenerAltura(auxiliar.hijoIzquierdo), obtenerAltura(auxiliar.hijoDerecho)) + 1;
        return auxiliar;
    }
    
     public NodoArbol rotacionDobleIzquierda(NodoArbol c) {
        NodoArbol temporal;
        c.hijoIzquierdo=rotacionDerecha(c.hijoIzquierdo);
        temporal = rotacionIzquierda(c);
        return temporal;
    }
    
     
    public NodoArbol rotacionDobleDerecha(NodoArbol c) {
        NodoArbol temporal;
        c.hijoDerecho=rotacionIzquierda(c.hijoDerecho);
        temporal = rotacionDerecha(c);
        return temporal;
    }

    public NodoArbol insertar(NodoArbol nuevo, NodoArbol subArbol) {
        NodoArbol nuevoPadre = subArbol;
        if (nuevo.valor < subArbol.valor) {
            if (subArbol.hijoIzquierdo == null) {
                subArbol.hijoIzquierdo = nuevo;
            } else {
                subArbol.hijoIzquierdo = insertar(nuevo, subArbol.hijoIzquierdo);
                if ((obtenerAltura(subArbol.hijoIzquierdo) - obtenerAltura(subArbol.hijoDerecho)) == 2) {
                    if (nuevo.valor < subArbol.hijoIzquierdo.valor) {
                        nuevoPadre = rotacionIzquierda(subArbol);
                    } else {
                        nuevoPadre = rotacionDobleIzquierda(subArbol);
                    }
                }
            }
        } else if (nuevo.valor > subArbol.valor) {
            if (subArbol.hijoDerecho == null) {
                subArbol.hijoDerecho = nuevo;
            } else {
                subArbol.hijoDerecho = insertar(nuevo, subArbol.hijoDerecho);
                if ((obtenerAltura(subArbol.hijoDerecho) - obtenerAltura(subArbol.hijoIzquierdo)) == 2) {
                    if (nuevo.valor > subArbol.hijoDerecho.valor) {
                        nuevoPadre = rotacionDerecha(subArbol);
                    } else {
                        nuevoPadre = rotacionDobleDerecha(subArbol);
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Nodo duplicado");
        }

        subArbol.altura = Math.max(obtenerAltura(subArbol.hijoIzquierdo), obtenerAltura(subArbol.hijoDerecho)) + 1;
        return nuevoPadre;
    }

    public void insertar(int valor) {
        NodoArbol nuevo = new NodoArbol(valor);
        if (raiz == null) {
            raiz = nuevo;
        } else {
            raiz = insertar(nuevo, raiz);
        }
    }

    public NodoArbol eliminar(NodoArbol nodo, int valor) {
        if (nodo == null) {
            return null;
        }
        if (valor < nodo.valor) {
            nodo.hijoIzquierdo = eliminar(nodo.hijoIzquierdo, valor);
        } else if (valor > nodo.valor) {
            nodo.hijoDerecho = eliminar(nodo.hijoDerecho, valor);
        } else {
            if (nodo.hijoIzquierdo == null) {
                return nodo.hijoDerecho;
            } else if (nodo.hijoDerecho == null) {
                return nodo.hijoIzquierdo;
            }
            NodoArbol sucesor = obtenerSucesor(nodo.hijoDerecho);
            nodo.valor = sucesor.valor;
            nodo.hijoDerecho = eliminar(nodo.hijoDerecho, sucesor.valor);
        }
        nodo.altura = Math.max(obtenerAltura(nodo.hijoIzquierdo), obtenerAltura(nodo.hijoDerecho)) + 1;
        return nodo;
    }

    private NodoArbol obtenerSucesor(NodoArbol nodo) {
        while (nodo.hijoIzquierdo != null) {
            nodo = nodo.hijoIzquierdo;
        }
        return nodo;
    }

    public boolean estaVacio() {
        return raiz == null;
    }

    public NodoArbol getRaiz() {
        return raiz;
    }    
    
    public static void main(String[] args) {
        
        Arbol arbol = new Arbol();

        SwingUtilities.invokeLater(() -> {
            Ventana ventana = new Ventana(arbol);
            ventana.setVisible(true);
        });
    }
}
    
