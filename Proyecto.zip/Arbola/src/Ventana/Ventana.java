package Ventana;

import java.awt.*;
import javax.swing.*;
import arbolbinario.Arbol;
import arbolbinario.NodoArbol;
import Lista.Lista;
import Lista.Nodo;
import Pila.Pila;
import Cola.Cola;

public class Ventana extends JFrame {
    private Arbol arbol;
    private Lista lista;
    private Pila pila;
    private Cola cola;
    private JPanel panel;
    private JTextField txtValor;
    private JButton btnInsertar, btnEliminar, btnCambiarEstructura;
    private String estructuraActual = "Arbol"; 

    public Ventana(Arbol arbol) {
        this.arbol = arbol;
        this.lista = new Lista();
        this.pila = new Pila();
        this.cola = new Cola();

        setTitle("Estructuras de Datos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
        
    }

    private void initComponents() {
        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                switch (estructuraActual) {
                    case "Arbol":
                        if (arbol.getRaiz() != null) {
                            dibujarArbol(g, arbol.getRaiz(), getWidth() / 2, 50, getWidth() / 4);
                        }
                        break;
                    case "Lista":
                        if (lista.cabeza != null) {
                            dibujarLista(g, lista.cabeza, 50, getHeight() / 2);
                        }
                        break;
                    case "Pila":
                        if (!pila.estaVacia()) {
                            dibujarPila(g, pila.getCima(), getWidth() / 2, 50);
                        }
                        break;
                    case "Cola":
                        if (!cola.estaVacia()) {
                            dibujarCola(g, cola.getFrente(), 50, getHeight() / 2);
                        }
                        break;
                }
            }
        };

        panel.setBackground(Color.decode("#282a36"));

        JPanel controlPanel = new JPanel();
        txtValor = new JTextField(5);
        btnInsertar = new JButton("Insertar");
        btnEliminar = new JButton("Eliminar");
        btnCambiarEstructura = new JButton("Cambiar Estructura");

        controlPanel.add(new JLabel("Valor:"));
        controlPanel.add(txtValor);
        controlPanel.add(btnInsertar);
        controlPanel.add(btnEliminar);
        controlPanel.add(btnCambiarEstructura);
        controlPanel.add(new JLabel("By: Dylan Gerhard Arce Triviño"));

        add(panel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        btnInsertar.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtValor.getText());
                switch (estructuraActual) {
                    case "Arbol":
                        arbol.insertar(valor);
                        break;
                    case "Lista":
                        lista.agregar(valor);
                        break;
                    case "Pila":
                        pila.push(valor);
                        break;
                    case "Cola":
                        cola.enqueue(valor);
                        break;
                }
                panel.repaint();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un valor válido.");
            }
        });

        btnEliminar.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtValor.getText());
                switch (estructuraActual) {
                    case "Arbol":
                        arbol.eliminar(arbol.getRaiz(), valor);
                        break;
                    case "Lista":
                        lista.eliminar(valor);
                        break;
                    case "Pila":
                        pila.pop();
                        break;
                    case "Cola":
                        cola.dequeue();
                        break;
                }
                panel.repaint();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Escriba un valor válido.");
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        btnCambiarEstructura.addActionListener(e -> {
            String[] opciones = {"Arbol", "Lista", "Pila", "Cola"};
            estructuraActual = (String) JOptionPane.showInputDialog(
                    this,
                    "Seleccione la estructura a visualizar:",
                    "Cambiar Estructura",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    opciones,
                    estructuraActual
            );
            panel.repaint();
        });
    }

    private void dibujarArbol(Graphics g, NodoArbol nodo, int x, int y, int xOffset) {
        if (nodo != null) {
            g.setColor(Color.decode("#ff81d5"));
            g.fillOval(x - 15, y - 15, 30, 30);
            g.setColor(Color.WHITE);
            g.drawString(String.valueOf(nodo.valor), x - 7, y + 5);

            if (nodo.hijoIzquierdo != null) {
                g.setColor(Color.decode("#EF97F0"));
                g.drawLine(x, y, x - xOffset, y + 50);
                dibujarArbol(g, nodo.hijoIzquierdo, x - xOffset, y + 50, xOffset / 2);
            }

            if (nodo.hijoDerecho != null) {
                g.setColor(Color.decode("#EF97F0"));
                g.drawLine(x, y, x + xOffset, y + 50);
                dibujarArbol(g, nodo.hijoDerecho, x + xOffset, y + 50, xOffset / 2);
            }
        }
    }

    private void dibujarLista(Graphics g, Nodo nodo, int x, int y) {
        while (nodo != null) {
            g.setColor(Color.decode("#8be9fd"));
            g.fillRect(x, y - 10, 40, 20);
            g.setColor(Color.decode("#FFFFFF"));
            g.drawString(String.valueOf(nodo.valor), x + 15, y + 5);
            nodo = nodo.siguiente;
            x += 50;
        }
    }

    private void dibujarPila(Graphics g, Nodo nodo, int x, int y) {
        while (nodo != null) {
            g.setColor(Color.decode("#bd93f9"));
            g.fillRect(x - 20, y, 40, 20);
            g.setColor(Color.decode("#FFFFFF"));
            g.drawString(String.valueOf(nodo.valor), x - 10, y + 15);
            nodo = nodo.siguiente;
            y += 30;
        }
    }

    private void dibujarCola(Graphics g, Nodo nodo, int x, int y) {
        while (nodo != null) {
            g.setColor(Color.decode("#50fa7b"));
            g.fillRect(x, y - 10, 40, 20);
            g.setColor(Color.decode("#FFFFFF"));
            g.drawString(String.valueOf(nodo.valor), x + 15, y + 5);
            nodo = nodo.siguiente;
            x += 50;
        }
    }
}
